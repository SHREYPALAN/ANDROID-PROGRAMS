package com.marwadi.labwork_18;


import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class SplashActivity extends AppCompatActivity {

    ProgressBar progressBar;
    TextView progressText;
    int progress = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        progressBar = findViewById(R.id.progressBar);
        progressText = findViewById(R.id.progressText);

        new Thread(() -> {
            while (progress <= 100) {
                try {
                    Thread.sleep(50);
                    progress++;

                    runOnUiThread(() -> {
                        progressBar.setProgress(progress);
                        progressText.setText(progress + "%");
                    });

                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

            startActivity(new Intent(SplashActivity.this, MainActivity.class));
            finish();

        }).start();
    }
}